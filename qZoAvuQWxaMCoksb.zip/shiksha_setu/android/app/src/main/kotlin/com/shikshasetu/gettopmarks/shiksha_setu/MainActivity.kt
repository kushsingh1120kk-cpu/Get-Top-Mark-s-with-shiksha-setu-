package com.shikshasetu.gettopmarks.shiksha_setu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
