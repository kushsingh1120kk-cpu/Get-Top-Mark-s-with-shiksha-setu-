import '../models/subject.dart';

class AppData {
  static final Map<String, List<Subject>> classSubjects = {
    '9': [
      Subject(id: '9_sci', nameEn: 'Science', nameHi: 'विज्ञान', chapters: []),
      Subject(id: '9_ss', nameEn: 'Social Science', nameHi: 'सामाजिक विज्ञान', chapters: []),
      Subject(id: '9_math', nameEn: 'Math', nameHi: 'गणित', chapters: []),
      Subject(id: '9_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '9_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '10': [
      Subject(id: '10_sci', nameEn: 'Science', nameHi: 'विज्ञान', chapters: []),
      Subject(id: '10_ss', nameEn: 'Social Science', nameHi: 'सामाजिक विज्ञान', chapters: []),
      Subject(id: '10_math', nameEn: 'Math', nameHi: 'गणित', chapters: []),
      Subject(id: '10_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '10_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '11_arts': [
      Subject(id: '11_hist', nameEn: 'History', nameHi: 'इतिहास', chapters: []),
      Subject(id: '11_pol', nameEn: 'Political Science', nameHi: 'राजनीति विज्ञान', chapters: []),
      Subject(id: '11_soc', nameEn: 'Sociology', nameHi: 'समाजशास्त्र', chapters: []),
      Subject(id: '11_geo', nameEn: 'Geography', nameHi: 'भूगोल', chapters: []),
      Subject(id: '11_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '11_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '11_sci': [
      Subject(id: '11_phy', nameEn: 'Physics', nameHi: 'भौतिक विज्ञान', chapters: []),
      Subject(id: '11_che', nameEn: 'Chemistry', nameHi: 'रसायन विज्ञान', chapters: []),
      Subject(id: '11_bio', nameEn: 'Biology', nameHi: 'जीव विज्ञान', chapters: []),
      Subject(id: '11_math', nameEn: 'Math', nameHi: 'गणित', chapters: []),
      Subject(id: '11_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '11_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '11_comm': [
      Subject(id: '11_acc', nameEn: 'Accountancy', nameHi: 'लेखाशास्त्र', chapters: []),
      Subject(id: '11_eco', nameEn: 'Economics', nameHi: 'अर्थशास्त्र', chapters: []),
      Subject(id: '11_bus', nameEn: 'Business Studies', nameHi: 'व्यवसाय अध्ययन', chapters: []),
      Subject(id: '11_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '11_hin', nameEn: 'Optional Hindi', nameHi: 'वैकल्पिक हिंदी', chapters: []),
      Subject(id: '11_cs', nameEn: 'Computer Science', nameHi: 'कंप्यूटर विज्ञान', chapters: []),
    ],
    // Similar for Class 12
    '12_arts': [
      Subject(id: '12_hist', nameEn: 'History', nameHi: 'इतिहास', chapters: []),
      Subject(id: '12_pol', nameEn: 'Political Science', nameHi: 'राजनीति विज्ञान', chapters: []),
      Subject(id: '12_soc', nameEn: 'Sociology', nameHi: 'समाजशास्त्र', chapters: []),
      Subject(id: '12_geo', nameEn: 'Geography', nameHi: 'भूगोल', chapters: []),
      Subject(id: '12_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '12_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '12_sci': [
      Subject(id: '12_phy', nameEn: 'Physics', nameHi: 'भौतिक विज्ञान', chapters: []),
      Subject(id: '12_che', nameEn: 'Chemistry', nameHi: 'रसायन विज्ञान', chapters: []),
      Subject(id: '12_bio', nameEn: 'Biology', nameHi: 'जीव विज्ञान', chapters: []),
      Subject(id: '12_math', nameEn: 'Math', nameHi: 'गणित', chapters: []),
      Subject(id: '12_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '12_hin', nameEn: 'Hindi', nameHi: 'हिंदी', chapters: []),
    ],
    '12_comm': [
      Subject(id: '12_acc', nameEn: 'Accountancy', nameHi: 'लेखाशास्त्र', chapters: []),
      Subject(id: '12_eco', nameEn: 'Economics', nameHi: 'अर्थशास्त्र', chapters: []),
      Subject(id: '12_bus', nameEn: 'Business Studies', nameHi: 'व्यवसाय अध्ययन', chapters: []),
      Subject(id: '12_eng', nameEn: 'English', nameHi: 'अंग्रेजी', chapters: []),
      Subject(id: '12_hin', nameEn: 'Optional Hindi', nameHi: 'वैकल्पिक हिंदी', chapters: []),
      Subject(id: '12_cs', nameEn: 'Computer Science', nameHi: 'कंप्यूटर विज्ञान', chapters: []),
    ],
  };
}
