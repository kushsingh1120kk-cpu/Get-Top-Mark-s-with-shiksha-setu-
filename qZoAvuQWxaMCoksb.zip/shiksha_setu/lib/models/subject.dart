class Subject {
  final String id;
  final String nameEn;
  final String nameHi;
  final List<Chapter> chapters;

  Subject({required this.id, required this.nameEn, required this.nameHi, required this.chapters});
}

class Chapter {
  final String id;
  final String titleEn;
  final String titleHi;
  final String pdfUrl;

  Chapter({required this.id, required this.titleEn, required this.titleHi, required this.pdfUrl});
}
