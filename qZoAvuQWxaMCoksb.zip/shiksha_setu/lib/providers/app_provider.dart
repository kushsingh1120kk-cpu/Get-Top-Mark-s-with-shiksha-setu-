import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppProvider with ChangeNotifier {
  Locale _locale = const Locale('en');
  bool _isDarkMode = true;
  List<String> _bookmarks = [];

  Locale get locale => _locale;
  bool get isDarkMode => _isDarkMode;
  List<String> get bookmarks => _bookmarks;

  AppProvider() {
    _loadFromPrefs();
  }

  void setLocale(String languageCode) {
    _locale = Locale(languageCode);
    _saveToPrefs();
    notifyListeners();
  }

  void toggleBookmark(String chapterId) {
    if (_bookmarks.contains(chapterId)) {
      _bookmarks.remove(chapterId);
    } else {
      _bookmarks.add(chapterId);
    }
    _saveToPrefs();
    notifyListeners();
  }

  Future<void> _loadFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final lang = prefs.getString('language') ?? 'en';
    _locale = Locale(lang);
    _bookmarks = prefs.getStringList('bookmarks') ?? [];
    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', _locale.languageCode);
    await prefs.setStringList('bookmarks', _bookmarks);
  }
}
