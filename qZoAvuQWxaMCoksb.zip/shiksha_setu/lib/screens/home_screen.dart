import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiksha_setu/providers/app_provider.dart';
import 'package:shiksha_setu/data/app_data.dart';
import 'package:shiksha_setu/screens/subject_list_screen.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  late stt.SpeechToText _speech;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
  }

  void _listen() async {
    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(onResult: (val) {
          setState(() {
            _searchController.text = val.recognizedWords;
            _isListening = false;
          });
        });
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final isHindi = appProvider.locale.languageCode == 'hi';

    return Scaffold(
      appBar: AppBar(
        title: Text(isHindi ? 'शिक्षा सेतु' : 'Shiksha Setu'),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () {
              appProvider.setLocale(isHindi ? 'en' : 'hi');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: isHindi ? 'खोजें...' : 'Search...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
                  onPressed: _listen,
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                filled: true,
                fillColor: Colors.grey[900],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildClassCard(context, '9', isHindi ? 'कक्षा 9' : 'Class 9'),
                _buildClassCard(context, '10', isHindi ? 'कक्षा 10' : 'Class 10'),
                _buildClassCard(context, '11_arts', isHindi ? 'कक्षा 11 (कला)' : 'Class 11 (Arts)'),
                _buildClassCard(context, '11_sci', isHindi ? 'कक्षा 11 (विज्ञान)' : 'Class 11 (Science)'),
                _buildClassCard(context, '11_comm', isHindi ? 'कक्षा 11 (वाणिज्य)' : 'Class 11 (Commerce)'),
                _buildClassCard(context, '12_arts', isHindi ? 'कक्षा 12 (कला)' : 'Class 12 (Arts)'),
                _buildClassCard(context, '12_sci', isHindi ? 'कक्षा 12 (विज्ञान)' : 'Class 12 (Science)'),
                _buildClassCard(context, '12_comm', isHindi ? 'कक्षा 12 (वाणिज्य)' : 'Class 12 (Commerce)'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClassCard(BuildContext context, String classId, String title) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SubjectListScreen(classId: classId, className: title),
            ),
          );
        },
      ),
    );
  }
}
