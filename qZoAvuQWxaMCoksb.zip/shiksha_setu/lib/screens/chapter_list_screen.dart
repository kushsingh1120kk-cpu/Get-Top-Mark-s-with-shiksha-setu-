import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiksha_setu/providers/app_provider.dart';
import 'package:shiksha_setu/models/subject.dart';

class ChapterListScreen extends StatelessWidget {
  final Subject subject;

  const ChapterListScreen({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final isHindi = appProvider.locale.languageCode == 'hi';

    return Scaffold(
      appBar: AppBar(title: Text(isHindi ? subject.nameHi : subject.nameEn)),
      body: subject.chapters.isEmpty
          ? Center(
              child: Text(
                isHindi ? 'कोई अध्याय उपलब्ध नहीं है' : 'No chapters available',
                style: const TextStyle(color: Colors.grey),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: subject.chapters.length,
              itemBuilder: (context, index) {
                final chapter = subject.chapters[index];
                final isBookmarked = appProvider.bookmarks.contains(chapter.id);

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    title: Text(isHindi ? chapter.titleHi : chapter.titleEn),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(
                            isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                            color: isBookmarked ? Colors.blue : null,
                          ),
                          onPressed: () => appProvider.toggleBookmark(chapter.id),
                        ),
                        const Icon(Icons.download),
                      ],
                    ),
                    onTap: () {
                      // Open PDF Viewer
                    },
                  ),
                );
              },
            ),
    );
  }
}
