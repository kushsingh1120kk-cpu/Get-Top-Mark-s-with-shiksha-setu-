import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiksha_setu/providers/app_provider.dart';
import 'package:shiksha_setu/data/app_data.dart';
import 'package:shiksha_setu/screens/chapter_list_screen.dart';

class SubjectListScreen extends StatelessWidget {
  final String classId;
  final String className;

  const SubjectListScreen({super.key, required this.classId, required this.className});

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final isHindi = appProvider.locale.languageCode == 'hi';
    final subjects = AppData.classSubjects[classId] ?? [];

    return Scaffold(
      appBar: AppBar(title: Text(className)),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: subjects.length,
        itemBuilder: (context, index) {
          final subject = subjects[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const CircleAvatar(
                backgroundColor: Color(0xFF1E88E5),
                child: Icon(Icons.book, color: Colors.white),
              ),
              title: Text(isHindi ? subject.nameHi : subject.nameEn),
              subtitle: Text(isHindi ? 'अध्याय और असाइनमेंट' : 'Chapters & Assignments'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChapterListScreen(subject: subject),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
