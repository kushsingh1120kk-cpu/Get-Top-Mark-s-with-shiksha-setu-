import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shiksha_setu/providers/app_provider.dart';
import 'package:shiksha_setu/screens/home_screen.dart';
import 'package:shiksha_setu/theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: const ShikshaSetuApp(),
    ),
  );
}

class ShikshaSetuApp extends StatelessWidget {
  const ShikshaSetuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppProvider>(
      builder: (context, appProvider, child) {
        return MaterialApp(
          title: 'Get Top Marks With Shiksha Setu',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.darkTheme,
          locale: appProvider.locale,
          home: const HomeScreen(),
        );
      },
    );
  }
}
